Version 1.0 of the SCS (Specialized Capital Ships) mod for Sins II Omens of War technical preview


Hello! 

Since I don't have a ton of time to write down everything right now, I'll just make sure I cover the most important parts. 

1. Instructions: 

In C:\Users\[username]\AppData\Local\sins2\mods folder copy and paste BOTH the "special_cap_ships" file folder and the "enabled_mods.json"

2. Misc:

This mod is mostly balanced and you shouldn't run into anything bad, but if you do please don't send a crash report (to save on the Sins II team's time).
If you notice a typo, or have a suggestion, please post it in dev-ama "Specialized Capital Ships Mod" topic (where you got this from).