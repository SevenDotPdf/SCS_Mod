Version 1.3a of the SCS (Specialized Capital Ships) mod for Sins II Omens of War technical preview


I still haven't updated this text document, lol /-_-/



1. Instructions: 

In C:\Users\[username]\AppData\Local\sins2\mods folder copy and paste BOTH the "special_cap_ships" file folder and the "enabled_mods.json"

2. Misc:

This mod is mostly balanced and you shouldn't run into anything bad, but if you do please don't send a crash report (to save on the Sins II team's time).
If you notice a typo, or have a suggestion, please post it in dev-ama "Specialized Capital Ships Mod" topic on the Sins II official discord server.