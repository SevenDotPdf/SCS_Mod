Hi.

This [[core_en.localized_text]] file keeps all the description/name changes of the Specialized Capital Ships mod
but reverts all the planet names back to Sins II variants and the Capital ship prefixes back to TDN. 

Just use this [[core_en.localized_text]] file in place of the other one. 

------------
Instructions:

Paste this file in the folder here >> C:\Users\[username]\AppData\Local\sins2\mods\special_cap_ships\localized_text

Overwrite or move the already existing [[core_en.localized_text]] file
-----------

That's it. :)